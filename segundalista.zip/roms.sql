/*
fiz uma entidade site 
fiz uma entidade avalição
fiz uma entidade download
coloquei codigo nas entidades como pk
coloquei os cod_(alguma coisa ) como fk, para pesquisar
e arrumei as ligações 
*/

drop table romsgenero;
drop table genero;
drop table avalicao;
drop table download;
drop table roms;
drop table console;
drop table sitep;

create table sitep(
codigo integer not null,
usuario char(100) not null,
nomesitep char (100) not null,
primary key (codigo)
);

insert into sitep (codigo, usuario, nomesitep) values 
(1, 'Admin', 'wowroms'), (2, 'Anonymous', 'wowroms');

create table console(
codigo integer not null,
cod_usuario integer not null,
nome char(100) not null,
foreign key (cod_usuario) references sitep(codigo),
primary key (codigo)
);

insert into console(codigo, cod_usuario, nome) values
(1,1,'super nintendo'), (2,1,'game boy');

create table roms(
codigo integer not null,
cod_console integer not null,
cod_usuario integer not null,
nome char(100)not null,
regiao char(100) not null,
foreign key (cod_console) references console(codigo),
foreign key (cod_usuario) references sitep(codigo),
primary key (codigo)
);

insert into roms(codigo,cod_usuario, cod_console, nome, regiao) values
(1,1,1,'Super Mario World','usa'), (2,1,1, 'Super Mário World', 'europa'),
(3,1,1,'Super Mario World','japao'), (4,1,1, 'Super Mário Kart','usa'),
(5,1,1,'Super Mario Kart','europa'), (6,1,1, 'Super Mário Kart', 'japao'),
(7,2,1,'Pokemon Yellow', 'usa'), (8,2,1,'Pokemon Yellow', 'japao');

create table download(
codigo integer not null,
cod_usuario integer not null,
cod_roms integer not null,
foreign key (cod_usuario) references sitep(codigo),
foreign key (cod_roms) references roms(codigo),
primary key (codigo)
);

insert into download(codigo, cod_usuario, cod_roms) values
(1,2,1), (2,2,4), (3,2,7);

create table avalicao(
codigo integer not null,
cod_usuario integer not null,
cod_roms integer not null,
ratings char (1),
foreign key (cod_usuario) references sitep(codigo),
foreign key (cod_roms) references roms(codigo),
primary key (codigo)
);

insert into avalicao(codigo, cod_usuario, cod_roms, ratings) values
(1,2,1, 4), (2,2,4, 5), (3,2,7, 3);

create table genero(
codigo integer not null,
genero char (100) not null,
primary key (codigo)
);

insert into genero(codigo, genero) values
(1, 'plataforma'), (2, 'corrida'), (3, 'rpg');

create table romsgenero(
cod_roms integer not null,
cod_genero integer not null,
foreign key (cod_roms) references roms(codigo),
foreign key (cod_genero) references genero(codigo),
primary key (cod_roms, cod_genero)
);

insert into romsgenero(roms, genero) values 
(1,1), (2,1), (3,1), (4,2), (5,2), (6,2), (7,3), (8,3), (9,3);

