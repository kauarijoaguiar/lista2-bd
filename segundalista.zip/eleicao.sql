    /*
fiz uma entidade turno
fiz uma entidade justificativa
fiz uma entidade votos
coloquei codigo nas entidades como pk
coloquei os cod_(alguma coisa ) como fk, para pesquisar
e arrumei as ligações 
*/

drop table eleicao;
drop table eleicao_cargo;
drop table justificativa;
drop table votos;
drop table eleitores;
drop table candidatos;
drop table partido;
drop table secao;
drop table zonas;
drop table cidade;
drop table turno;
drop table cargo;

create table cargo(
codigo integer not null,
nome char (100) not null,
primary key (codigo)
);
insert into cargo(codigo, nome) values
(1,'prefeito'),(2,'vereador'),(3,'deputado estadual');

create table turno(
codigo integer not null,
dataa date,
primary key (codigo)
);
insert into turno(codigo, dataa) values 
(1,'10-10-2021'),(2,'31-10-2021');

create table cidade(
codigo integer not null,
nome char(100) not null,
primary key(codigo)
);
insert into cidade(codigo, nome) values
(1,'Rio Grande'), (2,'São José do Norte');

create table zonas(
codigo integer not null,
cod_cidade integer not null,
numero integer not null,
foreign key (cod_cidade) references cidade(codigo),
primary key (codigo)
);
insert into zonas(codigo, cod_cidade, numero )values 
(1,1,123),(2,1,456),(3,1,789),(4,2,123),(5,2,456);

create table secao(
codigo integer not null,
cod_zonas integer not null,
numero integer not null,
foreign key (cod_zonas) references zonas(codigo),
primary key (codigo)
);
insert into secao(codigo, cod_zonas, numero )values
(1,1,001), (2,1,002), (3,2,003),(4,3,004),
(5,4,001),(6,5,002);

create table partido(
codigo integer not null,
nome char(100) not null,
legenda integer not null,
primary key (codigo)
);
insert into partido(codigo, nome, legenda) values
(1,'abc',12),(2,'def',34),(3,'ghi',56),(4,'jkl',78);

create table candidatos(
codigo integer not null,
cod_cidade integer,
cod_partido integer not null,
cod_cargo integer not null,
nome char(100) not null,
titulo integer not null,
numero integer not null,
foreign key (cod_cidade) references cidade(codigo),
foreign key (cod_partido) references partido(codigo),
foreign key (cod_cargo) references cargo(codigo),
primary key (codigo)
);

insert into candidatos(codigo,cod_cidade,cod_partido, cod_cargo, nome,titulo,numero) values
(1,null,1,3,'Ana Bragança Rocha', 00012, 120),
(2,null, 1,3,'Paulo Silva Mendes', 00389, 121),
(3,null,2,3,'Maria Medeiros Oliveira', 00419, 340),
(4,null,3,3,'Carlos Avila Machado', 00551, 561 ),
(5,null,4,3,'Carolina Xavier Silva', 00865, 780),
(6,1,1,1,'Joao Silva Brasil',10982,12),
(7,1,2,1,'Maria Pereira Braz', 13613, 34),
(8,1,3,1 ,'Pedro Barros Oliveira',15334, 56),
(9,2,1,1,'Maria Vilas Oliveira', 12543, 12),
(10,2,3,1, 'Carlos Jardim Lemos', 22987, 56),
(11,1,1,2,'Vitor Braga Nunes',16850,1200),
(12,1,1,2,'Felipe Rosa Andrade',19814,1205),
(13,1,2,2,'Julia Rosa Andrade',24997,3401),
(14,1,3,2,'Milena Alves Rodriguez',29883,5603),
(15,1,2,2,'Alexandre Santos Brasil',30979,5607),
(16,1,4,2,'Luciano Mendes Ávila',36546,7802) ,
(17,1,4,2,'Tiago Oliveira Bezerra',40485,7809),
(18,2,1,2,'Rodrigo Domingues Souto',17934, 1200),
(19,2,3,2,'Gustavo Souza Braga',12580,5601);

create table eleitores(
codigo integer not null,
cod_secao integer not null,
nome char(100) not null,
titulo integer not null,
sexo char (100) not null,
nascimento date,
foreign key (cod_secao) references secao(codigo),
primary key (codigo)
);
insert into eleitores(codigo, cod_secao, nome, titulo, sexo, nascimento) values
(1,3,'João Silva Brasil', 10982, 'masculino', '06-03-1991'),
(2,2,'Maria Pereira Braz', 13613, 'feminino','09-09-1991'),
(3,4,'Pedro Barros Oliveira', 15334, 'masculino', '15-01-1996'),
(4,4,'Julian Rosa Andrade', 24997, 'feminino', '17-10-1998');

create table votos(
codigo integer not null,
cod_turno integer not null,
cod_eleitores integer not null,
hora time,
dataa date,
votod char(10) not null,
votop char(10) not null,
votov char(10) not null,
foreign key (cod_turno) references turno(codigo),
foreign key (cod_eleitores) references eleitores(codigo),
primary key (codigo)
);

insert into votos(codigo, cod_turno, cod_eleitores, hora, dataa, votod, votop, votov) values

(1,1,1,'15:00','10-10-2021',561,12,'branco'),
(2,1,2,'15:10','10-10-2021',121,34,'nulo'),
(3,1,3,'15:20','10-10-2021','branco',56,3401);

create table justificativa(
codigo integer not null,
cod_eleitores integer not null,
hora time,
dataa date,
foreign key (cod_eleitores) references eleitores(codigo),
primary key (codigo)
);

insert into justificativa(codigo,cod_eleitores, hora, dataa) values
(1,4,'14:10','13-10-2021');

create table eleicao_cargo(
    cod_cargo integer not null,
    cod_eleicao integer not null,
    foreign key (cod_cargo) references cargo(codigo),
    foreign key (cod_eleicao) references eleicao(codigo),
    primary key(cod_cargo, cod_eleicao)
);

create table eleicao(
    codigo integer not null,
    cod_votos integer not null,
    foreign key (cod_votos) references votos(codigo),
    primary key (codigo)
);